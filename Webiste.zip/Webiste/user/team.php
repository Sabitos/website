<?php
// public_html/user/team.php

require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) redirect(BASE_URL);

$pdo     = Database::getInstance()->getConnection();
$user    = fetchUserByDiscordId($_SESSION['user']['discord_id']);
$isAdmin = isAdmin();

// 1) Încarcă echipa + căpitan
$teamId = (int)($_GET['id'] ?? 0);
$stmt   = $pdo->prepare("
  SELECT
    t.id, t.name, t.captain_id,
    u.display_name   AS captain_name,
    u.username       AS captain_user,
    u.discriminator  AS captain_disc,
    u.discord_id     AS captain_did,
    u.avatar         AS captain_av
  FROM teams t
  JOIN users u ON u.id = t.captain_id
  WHERE t.id = :tid
");
$stmt->execute(['tid' => $teamId]);
$team = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$team) {
  die('<div class="container py-5"><div class="alert alert-danger">Echipa nu există.</div></div>');
}

// 2) Încarcă membrii
$mem = $pdo->prepare("
  SELECT
    u.id, u.display_name, u.username, u.discriminator,
    u.discord_id, u.avatar, tm.position
  FROM team_members tm
  JOIN users u ON u.id = tm.user_id
  WHERE tm.team_id = :tid
");
$mem->execute(['tid' => $teamId]);
$members = $mem->fetchAll(PDO::FETCH_ASSOC);

// 3) Permisiuni
$isCaptain = ((int)$user['id'] === (int)$team['captain_id']);

// 4) Trimite invitații
$errors  = [];
$success = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && getPost('add_member') && ($isCaptain || $isAdmin)) {
  check_csrf();
  $slots    = ['Ascendant','Diamond','Platinum','Gold'];
  $occupied = array_merge([$team['captain_id']], array_column($members, 'id'));

  foreach ($slots as $rank) {
    $riot = trim(getPost('riot_' . strtolower($rank)) ?: '');
    if ($riot === '') continue;

    // Găsește user după Riot ID
    $chk = $pdo->prepare("
      SELECT id, current_rank, rank_status, discord_id
      FROM users WHERE riot_id = :riot
    ");
    $chk->execute(['riot' => $riot]);
    $u = $chk->fetch(PDO::FETCH_ASSOC);

    if (!$u) {
      $errors[] = "Riot ID „{$riot}” nu există.";
      continue;
    }
    if ($u['rank_status'] !== 'approved') {
      $errors[] = "@{$riot} nu are rank aprobat.";
      continue;
    }
    // Permit sufix numeric: comparăm prefixul
    if (stripos($u['current_rank'], $rank) !== 0) {
      $errors[] = "@{$riot} are rank „{$u['current_rank']}”, nu „{$rank}”";
      continue;
    }
    if (in_array($u['id'], $occupied, true)) {
      $errors[] = "@{$riot} este deja în echipă.";
      continue;
    }

    // Creează invitația
    $pdo->prepare("
      INSERT INTO team_invites (team_id, user_id, invited_by)
      VALUES (:tid, :uid, :by)
    ")->execute([
      'tid' => $teamId,
      'uid' => $u['id'],
      'by'  => $user['id']
    ]);

    $success[]  = "Invitație trimisă către @{$riot}.";
    $occupied[] = $u['id'];
  }
}

// 5) Afișează pagina
$pageTitle = 'Echipa: ' . sanitize($team['name']);
include __DIR__.'/../includes/header.php';
include __DIR__.'/../includes/navbar.php';
?>

<div class="container py-5">
  <h1 class="mb-4"><i class="bi bi-people-fill me-1"></i>Echipa: <?= sanitize($team['name']) ?></h1>

 <!-- Membri (inclusiv căpitanul) -->
<div class="card mb-4">
  <div class="card-header bg-secondary text-white">
    <i class="bi bi-people me-1"></i> Membri (<?= count($members) + 1 ?>)
  </div>
  <ul class="list-group list-group-flush">

    <!-- Căpitanul -->
    <?php
      $capDid = $team['captain_did'];
      $capAv  = $team['captain_av'];
      $capName = $team['captain_name'];
      $capTag  = "{$team['captain_user']}#{$team['captain_disc']}";
      $capUrl  = $capAv
        ? "https://cdn.discordapp.com/avatars/{$capDid}/{$capAv}.png"
        : "https://cdn.discordapp.com/embed/avatars/".($capDid % 5).".png";
    ?>
    <li class="list-group-item d-flex align-items-center bg-light">
      <img src="<?= sanitize($capUrl) ?>"
           alt="Avatar căpitan"
           class="rounded-circle me-3"
           width="48" height="48">
      <div class="flex-grow-1">
        <h6 class="mb-1"><?= sanitize($capName) ?> <span class="badge bg-warning text-dark">Căpitan</span></h6>
        <a href="https://discord.com/users/<?= sanitize($capDid) ?>"
           target="_blank"
           class="small text-decoration-none">
          <?= sanitize($capTag) ?>
        </a>
      </div>
    </li>

    <!-- Restul membrilor -->
    <?php if (empty($members)): ?>
      <li class="list-group-item text-muted">Nu există alți membri.</li>
    <?php else: foreach ($members as $m):
      $did    = $m['discord_id'];
      $av     = $m['avatar'];
      $name   = $m['display_name'];
      $tag    = "{$m['username']}#{$m['discriminator']}";
      $url    = $av
        ? "https://cdn.discordapp.com/avatars/{$did}/{$av}.png"
        : "https://cdn.discordapp.com/embed/avatars/".($did % 5).".png";
    ?>
      <li class="list-group-item d-flex align-items-center">
        <img src="<?= sanitize($url) ?>"
             alt="Avatar membru"
             class="rounded-circle me-3"
             width="48" height="48">
        <div class="flex-grow-1">
          <h6 class="mb-1"><?= sanitize($name) ?> <span class="badge bg-secondary"><?= sanitize($m['position']) ?></span></h6>
          <a href="https://discord.com/users/<?= sanitize($did) ?>"
             target="_blank"
             class="small text-decoration-none">
            <?= sanitize($tag) ?>
          </a>
        </div>
      </li>
    <?php endforeach; endif; ?>

  </ul>
</div>

  <?php if ($isCaptain || $isAdmin): ?>
    <div class="card shadow-sm">
      <div class="card-header">
        <i class="bi bi-envelope-paper me-1"></i> Trimite invitații
      </div>
      <div class="card-body">

        <?php if ($errors): ?>
          <div class="alert alert-danger"><ul class="mb-0">
            <?php foreach ($errors as $e): ?>
              <li><?= sanitize($e) ?></li>
            <?php endforeach; ?>
          </ul></div>
        <?php endif; ?>

        <?php if ($success): ?>
          <div class="alert alert-success"><ul class="mb-0">
            <?php foreach ($success as $s): ?>
              <li><?= sanitize($s) ?></li>
            <?php endforeach; ?>
          </ul></div>
        <?php endif; ?>

        <form method="post" class="row g-3">
          <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
          <input type="hidden" name="add_member" value="1">

          <?php foreach (['Ascendant','Diamond','Platinum','Gold'] as $rank): ?>
            <div class="col-md-3">
              <label class="form-label"><?= sanitize($rank) ?></label>
              <input type="text"
                     name="riot_<?= strtolower($rank) ?>"
                     class="form-control"
                     placeholder="Riot ID">
              <div class="form-text"><?= sanitize($rank) ?> (Riot ID)</div>
            </div>
          <?php endforeach; ?>

          <div class="col-12 text-end">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-envelope me-1"></i> Trimite invitații
            </button>
          </div>
        </form>

      </div>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
