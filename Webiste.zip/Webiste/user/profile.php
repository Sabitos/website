<?php
// public_html/user/profile.php

require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) redirect(BASE_URL);

// Helper upload imagine rank
function handleRankUpload(int $userId): string {
    if (!isset($_FILES['rank_image']) || $_FILES['rank_image']['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Eroare la upload imagine.');
    }
    $ext      = pathinfo($_FILES['rank_image']['name'], PATHINFO_EXTENSION);
    $fileName = "{$userId}_" . time() . ".{$ext}";
    $dir      = __DIR__ . '/../assets/uploads/ranks/';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        throw new RuntimeException('Nu pot crea directorul de upload.');
    }
    if (!is_writable($dir)) {
        throw new RuntimeException('Permisiuni insuficiente pe directorul de upload.');
    }
    $dest    = $dir . $fileName;
    $relPath = 'uploads/ranks/' . $fileName;
    if (!move_uploaded_file($_FILES['rank_image']['tmp_name'], $dest)) {
        throw new RuntimeException('Nu am mutat fișierul.');
    }
    return $relPath;
}

// 1) DB + user
$pdo   = Database::getInstance()->getConnection();
$user  = fetchUserByDiscordId($_SESSION['user']['discord_id']);

// 2) Aflăm echipa (dacă există)
$teamInfo = fetchUserTeam((int)$user['id']);

// 3) Procesăm POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    // --- Socials & RiotID ---
    if (getPost('social_submit') !== null) {
        $tik    = getPost('tiktok_handle')  ?: null;
        $twi    = getPost('twitch_handle')  ?: null;
        $you    = getPost('youtube_handle') ?: null;
        $riotId = getPost('riot_id')        ?: null;

        // setăm Riot ID doar prima dată
        if ($riotId && empty($user['riot_id'])) {
            $stmt = $pdo->prepare("UPDATE users SET riot_id = :riot WHERE id = :id");
            $stmt->execute([
                'riot'=> sanitize($riotId),
                'id'  => $user['id']
            ]);
        }

        // actualizăm socials
        $stmt = $pdo->prepare("
          UPDATE users SET
            tiktok_handle  = :tik,
            twitch_handle  = :twi,
            youtube_handle = :you
          WHERE id = :id
        ");
        $stmt->execute([
            'tik'=> sanitize($tik),
            'twi'=> sanitize($twi),
            'you'=> sanitize($you),
            'id' => $user['id']
        ]);

        redirect(BASE_URL . '/user/profile.php');
    }

    // --- Verificare rank ---
    if (getPost('rank_submit') !== null && ($user['rank_status'] ?? 'none') === 'none') {
        $url      = getPost('profile_url', FILTER_VALIDATE_URL);
        $rankName = getPost('rank_name');
        $allowed  = ['Iron','Bronze','Silver','Gold','Platinum','Diamond','Ascendant','Immortal','Radiant'];

        if (!$url || !in_array($rankName, $allowed, true)) {
            die('URL invalid sau rank invalid. Alege una din: ' . implode(', ', $allowed));
        }

        try {
            $imgPath = handleRankUpload($user['id']);
        } catch (Exception $e) {
            die($e->getMessage());
        }

        $pdo->prepare("
          INSERT INTO rank_requests
            (user_id, profile_url, rank_name, image_path)
          VALUES
            (:uid, :url, :rn, :img)
        ")->execute([
          'uid'=> $user['id'],
          'url'=> $url,
          'rn' => $rankName,
          'img'=> $imgPath
        ]);

        $pdo->prepare("UPDATE users SET rank_status = 'pending' WHERE id = :id")
            ->execute(['id'=>$user['id']]);
        $_SESSION['user']['rank_status'] = 'pending';

        redirect(BASE_URL . '/user/profile.php');
    }
}

// 4) Refresh user după update
$user = fetchUserByDiscordId($user['discord_id']);
$_SESSION['user'] = $user;

// 5) Pregătire variabile afișare
$discInt     = intval($user['discriminator'] ?? 0);
$avatarUrl   = $user['avatar']
    ? "https://cdn.discordapp.com/avatars/{$user['discord_id']}/{$user['avatar']}.png"
    : "https://cdn.discordapp.com/embed/avatars/".($discInt % 5).".png";
$displayName = $user['display_name'] ?? $user['username'];
$tag         = "{$user['username']}#{$user['discriminator']}";
$memberSince = date_format(date_create($user['created_at']), 'j M Y');
$roles       = json_decode($user['roles'] ?? '[]', true) ?: [];

// 6) Conexiuni
$socials = [
  ['icon'=>'bi-discord text-info',    'url'=>"https://discord.com/users/{$user['discord_id']}",                           'label'=>"@{$user['username']}"],
  ['icon'=>'bi-controller text-primary','url'=>$user['riot_id'] ? "https://tracker.gg/valorant/profile/riot/".urlencode($user['riot_id'])."/overview" : null,'label'=>$user['riot_id']?"@{$user['riot_id']}":"Riot ID nesetat"],
  ['icon'=>'bi-tiktok',                'url'=>!empty($user['tiktok_handle'])?"https://tiktok.com/@".ltrim($user['tiktok_handle'],'@'):null,                'label'=>!empty($user['tiktok_handle'])?"@{$user['tiktok_handle']}":"TikTok nesetat"],
  ['icon'=>'bi-twitch',                'url'=>!empty($user['twitch_handle'])?"https://twitch.tv/".ltrim($user['twitch_handle'],'@'):null,                    'label'=>!empty($user['twitch_handle'])?"@{$user['twitch_handle']}":"Twitch nesetat"],
  ['icon'=>'bi-youtube text-danger',   'url'=>!empty($user['youtube_handle'])?"https://youtube.com/@".ltrim($user['youtube_handle'],'@'):null,                 'label'=>!empty($user['youtube_handle'])?"@{$user['youtube_handle']}":"YouTube nesetat"],
];

$pageTitle = 'Profil – VOSZ';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="container py-4">
  <!-- Profile Card -->
  <div class="card mb-4 shadow-sm overflow-hidden">
    <img src="<?= BASE_URL ?>/assets/img/banner-default.jpg"
         class="card-img-top" style="height:180px;object-fit:cover;">
    <div class="card-body text-center position-relative pt-5">
      <img src="<?= sanitize($avatarUrl) ?>"
           class="rounded-circle border border-white position-absolute top-0 start-50 translate-middle"
           style="width:120px;height:120px;object-fit:cover;transform:translate(-50%,-50%);">
      <h2 class="mt-5"><?= sanitize($displayName) ?></h2>
      <p class="text-muted mb-1"><?= sanitize($tag) ?></p>
      <p class="text-muted small">Member since <?= sanitize($memberSince) ?></p>
      <?php if ($teamInfo): ?>
        <p><i class="bi bi-people-fill me-1"></i>Echipa: <strong><?= sanitize($teamInfo['name']) ?></strong></p>
      <?php endif; ?>
      <?php foreach ($roles as $r): ?>
        <span class="badge bg-secondary me-1"><?= sanitize($r) ?></span>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Edit Settings Button -->
  <div class="text-end mb-4">
    <button class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#settingsModal">
      <i class="bi bi-gear-fill me-1"></i>Edit Profile Settings
    </button>
  </div>

  <div class="row gx-4 gy-4">
    <!-- Connections -->
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header"><i class="bi bi-link-45deg me-1"></i>Connections</div>
        <ul class="list-group list-group-flush">
          <?php foreach ($socials as $soc): ?>
            <li class="list-group-item d-flex align-items-center">
              <i class="bi <?= $soc['icon'] ?> me-2"></i>
              <?php if ($soc['url']): ?>
                <a href="<?= sanitize($soc['url']) ?>" target="_blank"><?= sanitize($soc['label']) ?></a>
              <?php else: ?>
                <span class="badge bg-warning text-dark"><?= sanitize($soc['label']) ?></span>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>

    <!-- Rank Status -->
    <div class="col-md-6">
      <div class="card shadow-sm mb-4">
        <div class="card-body">
          <?php switch($user['rank_status'] ?? 'none'):
            case 'none': ?>
              <div class="alert alert-warning mb-0">
                <i class="bi bi-exclamation-circle me-1"></i>Rank not verified yet.
              </div>
            <?php break; case 'pending': ?>
              <div class="alert alert-info mb-0">
                <i class="bi bi-hourglass-split me-1"></i>Verification <strong>pending</strong>.
              </div>
            <?php break; case 'rejected': ?>
              <div class="alert alert-danger mb-0">
                <i class="bi bi-x-circle me-1"></i>Verification <strong>rejected</strong>.
              </div>
            <?php break; default:
              $cat = getRankCategory($user['current_rank']);
            ?>
              <div class="alert alert-success mb-0">
                <i class="bi bi-patch-check-fill me-1"></i>Rank approved: <strong><?= sanitize($cat) ?></strong>
              </div>
          <?php endswitch; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Settings Modal -->
<div class="modal fade" id="settingsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-gear-fill me-2"></i>Profile Settings</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <ul class="nav nav-tabs mb-3" role="tablist">
          <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#socials-settings" type="button"><i class="bi bi-people-fill me-1"></i>Socials</button></li>
          <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#rank-settings" type="button"><i class="bi bi-award me-1"></i>Verify Rank</button></li>
        </ul>

        <div class="tab-content">
          <!-- Socials Tab -->
          <div class="tab-pane fade show active" id="socials-settings">
            <form method="post" class="row g-3">
              <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
              <input type="hidden" name="social_submit" value="1">

              <!-- Riot ID -->
              <div class="col-md-4">
                <label for="riot_id" class="form-label"><i class="bi bi-controller me-1"></i>Riot ID</label>
                <?php if (empty($user['riot_id'])): ?>
                  <input id="riot_id" name="riot_id" type="text" class="form-control" placeholder="Ex: Platinaxxx">
                  <small class="text-warning">⚠️ Doar o singură dată.</small>
                <?php else: ?>
                  <input type="text" class="form-control" value="<?= sanitize($user['riot_id']) ?>" disabled>
                  <small class="text-muted">✅ Riot ID setat.</small>
                <?php endif; ?>
              </div>

              <!-- TikTok -->
              <div class="col-md-4">
                <label for="tiktok_handle" class="form-label"><i class="bi bi-tiktok me-1"></i>TikTok @handle</label>
                <input id="tiktok_handle" name="tiktok_handle" type="text" class="form-control" placeholder="@username" value="<?= sanitize($user['tiktok_handle'] ?? '') ?>">
              </div>

              <!-- Twitch -->
              <div class="col-md-4">
                <label for="twitch_handle" class="form-label"><i class="bi bi-twitch me-1"></i>Twitch @handle</label>
                <input id="twitch_handle" name="twitch_handle" type="text" class="form-control" placeholder="@username" value="<?= sanitize($user['twitch_handle'] ?? '') ?>">
              </div>

              <!-- YouTube -->
              <div class="col-md-4">
                <label for="youtube_handle" class="form-label"><i class="bi bi-youtube me-1"></i>YouTube @handle</label>
                <input id="youtube_handle" name="youtube_handle" type="text" class="form-control" placeholder="@username" value="<?= sanitize($user['youtube_handle'] ?? '') ?>">
              </div>

              <div class="col-12 text-end">
                <button type="submit" class="btn btn-primary">Salvează Socials</button>
              </div>
            </form>
          </div>

          <!-- Rank Verification Tab -->
          <div class="tab-pane fade" id="rank-settings">
            <form method="post" enctype="multipart/form-data" class="row g-3">
              <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
              <input type="hidden" name="rank_submit" value="1">

              <div class="col-md-6">
                <label for="profile_url" class="form-label">Tracker URL</label>
                <input type="url" id="profile_url" name="profile_url" class="form-control" placeholder="https://tracker.gg/…" required>
              </div>

              <div class="col-md-4">
                <label for="rank_name" class="form-label">Current Rank</label>
                <select id="rank_name" name="rank_name" class="form-select" required>
                  <option value="">Alege rank</option>
                  <?php foreach (['Iron','Bronze','Silver','Gold','Platinum','Diamond','Ascendant','Immortal','Radiant'] as $r): ?>
                    <option value="<?= $r ?>"><?= $r ?></option>
                  <?php endforeach; ?>
                </select>
              </div>

              <div class="col-md-6">
                <label for="rank_image" class="form-label">Screenshot</label>
                <input type="file" id="rank_image" name="rank_image" class="form-control" accept="image/*" required>
              </div>

              <div class="col-12 text-end">
                <button type="submit" class="btn btn-primary">Submit Verification</button>
              </div>
            </form>
          </div>

        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
