<?php
// public_html/user/invites.php

require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) redirect(BASE_URL);

$pdo    = Database::getInstance()->getConnection();
$userId = $_SESSION['user']['id'];

// 1) Preluăm invitațiile în așteptare
$stmt = $pdo->prepare("
  SELECT
    i.id            AS invite_id,
    t.id            AS team_id,
    t.name          AS team_name,
    u.id            AS inviter_id,
    u.display_name  AS inviter_name,
    u.discord_id    AS inviter_did,
    u.avatar        AS inviter_av,
    i.created_at    AS sent_at
  FROM team_invites i
  JOIN teams t   ON t.id = i.team_id
  JOIN users u   ON u.id = i.invited_by
  WHERE i.user_id = :uid
  ORDER BY i.created_at DESC
");
$stmt->execute(['uid' => $userId]);
$invites = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Invitații primite';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="container py-5">
  <h1 class="mb-4"><i class="bi bi-envelope-paper me-1"></i>Invitații primite</h1>

  <?php if (empty($invites)): ?>
    <div class="alert alert-info">
      <i class="bi bi-info-circle me-1"></i>
      Nu ai nicio invitație în așteptare.
    </div>
  <?php else: ?>
    <div class="row gy-4">
      <?php foreach ($invites as $inv):
        $did    = $inv['inviter_did'];
        $av     = $inv['inviter_av'];
        $avatar = $av
          ? "https://cdn.discordapp.com/avatars/{$did}/{$av}.png"
          : "https://cdn.discordapp.com/embed/avatars/".($did%5).".png";
        $sentAt = date('j M Y, H:i', strtotime($inv['sent_at']));
      ?>
      <div class="col-md-6">
        <div class="card shadow-sm">
          <div class="card-body d-flex">
            <img src="<?= sanitize($avatar) ?>"
                 class="rounded-circle me-3"
                 width="64" height="64"
                 alt="Avatar inviter">
            <div class="flex-grow-1">
              <h5 class="card-title mb-1"><?= sanitize($inv['inviter_name']) ?></h5>
              <p class="text-muted small mb-2">
                te-a invitat în echipa
                <strong><?= sanitize($inv['team_name']) ?></strong>
              </p>
              <p class="text-muted small mb-0">
                <i class="bi bi-clock me-1"></i><?= sanitize($sentAt) ?>
              </p>
            </div>
          </div>
          <div class="card-footer bg-transparent d-flex justify-content-end">
            <button
              class="btn btn-sm btn-success me-2"
              onclick="respondInvite(<?= (int)$inv['invite_id'] ?>, true)">
              <i class="bi bi-check-lg me-1"></i>Acceptă
            </button>
            <button
              class="btn btn-sm btn-danger"
              onclick="respondInvite(<?= (int)$inv['invite_id'] ?>, false)">
              <i class="bi bi-x-lg me-1"></i>Respinge
            </button>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<script>
async function respondInvite(inviteId, accept) {
  const res = await fetch('<?= BASE_URL ?>/api/invite_response.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ invite_id: inviteId, accept })
  });
  if (res.ok) {
    // Remove card or reload
    location.reload();
  } else {
    alert('Eroare la procesarea invitației.');
  }
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
