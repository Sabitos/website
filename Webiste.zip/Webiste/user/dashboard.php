<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) {
    redirect(BASE_URL);
}

$pdo = Database::getInstance()->getConnection();

// Înscriere turneu
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $tId = getPost('tournament_id', FILTER_SANITIZE_NUMBER_INT);
    if ($tId !== null) {
        $stmt = $pdo->prepare("
          INSERT IGNORE INTO registrations
            (user_id, tournament_id, registered_at)
          VALUES
            (:u, :t, NOW())
        ");
        $stmt->execute([
            'u' => $_SESSION['user']['id'],
            't' => $tId
        ]);
    }
    redirect(BASE_URL . '/user/dashboard.php');
}

// Preluăm turnee
$available = $pdo
    ->query("SELECT * FROM tournaments WHERE status != 'finished'")
    ->fetchAll();

$stmt = $pdo->prepare("
  SELECT t.*
  FROM tournaments t
  JOIN registrations r ON r.tournament_id = t.id
  WHERE r.user_id = :uid
");
$stmt->execute(['uid' => $_SESSION['user']['id']]);
$mine = $stmt->fetchAll();
?>
<!doctype html>
<html lang="ro">
<head>
    <?php
    $pageTitle = 'Dashboard – VOSZ';
    include __DIR__ . '/../includes/header.php';
    ?>
</head>
<body class="bg-light">
<?php include __DIR__ . '/../includes/navbar.php'; ?>

<div class="container py-4">
  <h2>Turnee Disponibile</h2>
  <div class="row g-3">
    <?php foreach ($available as $t): ?>
    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title"><?= sanitize($t['name']) ?></h5>
          <p class="card-text"><?= sanitize($t['description']) ?></p>
          <p><small>Start: <?= sanitize($t['start_date']) ?></small></p>

          <?php
            $chk = $pdo->prepare("
              SELECT 1 FROM registrations
              WHERE user_id = :u AND tournament_id = :t
            ");
            $chk->execute([
              'u' => $_SESSION['user']['id'],
              't' => $t['id']
            ]);
          ?>

          <?php if (! $chk->fetchColumn()): ?>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
              <input type="hidden" name="tournament_id" value="<?= sanitize((string)$t['id']) ?>">
              <button class="btn btn-primary btn-sm">Înscrie-te</button>
            </form>
          <?php else: ?>
            <span class="badge bg-success">Înscris</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <h2 class="mt-5">Turneele Tale</h2>
  <ul class="list-group">
    <?php foreach ($mine as $t): ?>
    <li class="list-group-item">
      <?= sanitize($t['name']) ?> – <?= sanitize($t['start_date']) ?>
    </li>
    <?php endforeach; ?>
  </ul>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
