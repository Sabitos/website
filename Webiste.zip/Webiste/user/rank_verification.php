<?php
// user/rank_verification.php
// Aici doar logica/formularul de rank verification, fără header/footer

// Protecție CSRF deja inclusă
?>
<h4>Verificare Rank</h4>

<?php $status = $user['rank_status'] ?? 'none'; ?>

<?php if ($status === 'none'): ?>
  <p class="text-warning">
    Trimite mai jos profilul tracker și screenshot-ul rank‑ului.
  </p>

  <form method="post" enctype="multipart/form-data" class="row g-3 mb-5">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <input type="hidden" name="rank_submit" value="1">

    <div class="col-md-6">
      <label class="form-label" for="profile_url">Profil Tracker URL</label>
      <input
        type="url"
        id="profile_url"
        name="profile_url"
        class="form-control"
        placeholder="https://tracker.gg/…"
        required>
    </div>

    <div class="col-md-4">
      <label class="form-label" for="rank_name">Rank Actual</label>
      <input
        type="text"
        id="rank_name"
        name="rank_name"
        class="form-control"
        placeholder="Ex: Platinum 2"
        required>
    </div>

    <div class="col-md-6">
      <label class="form-label" for="rank_image">Screenshot Rank</label>
      <input
        type="file"
        id="rank_image"
        name="rank_image"
        class="form-control"
        accept="image/*"
        required>
    </div>

    <div class="col-12">
      <button type="submit" class="btn btn-primary">
        Trimite cerere verificare rank
      </button>
    </div>
  </form>
<?php endif; ?>
