<?php
// public_html/user/players.php

require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) redirect(BASE_URL);

$pdo = Database::getInstance()->getConnection();
$rows = $pdo->query("
  SELECT id, display_name, discord_id, avatar
  FROM users
  ORDER BY display_name
")->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Membri – VOSZ';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container py-5">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="bi bi-people-fill me-1"></i>Membri</h1>
    <input id="searchInput" type="text" class="form-control w-auto" placeholder="Caută jucător…">
  </div>

  <div id="playersGrid" class="row g-4">
    <!-- card-urile vor fi injectate aici de JS -->
  </div>

  <nav class="d-flex justify-content-center mt-4">
    <ul id="pagination" class="pagination"></ul>
  </nav>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<script>
(() => {
  const rows = <?= json_encode($rows) ?>;
  const perPage = 12;
  let currentPage = 1;
  let filtered = rows;

  const grid = document.getElementById('playersGrid');
  const pagUL = document.getElementById('pagination');
  const search = document.getElementById('searchInput');

  function renderPage(page) {
    grid.innerHTML = '';
    const start = (page - 1) * perPage;
    const slice = filtered.slice(start, start + perPage);
    if (!slice.length) {
      grid.innerHTML = `<div class="col-12 text-center text-muted">Nu există membri.</div>`;
    } else {
      for (const u of slice) {
        const did = u.discord_id;
        const av = u.avatar
          ? `https://cdn.discordapp.com/avatars/${did}/${u.avatar}.png`
          : `https://cdn.discordapp.com/embed/avatars/${parseInt(did)%5}.png`;
        const name = u.display_name;
        grid.insertAdjacentHTML('beforeend', `
          <div class="col-sm-6 col-md-4 col-lg-3">
            <div class="card h-100 text-center shadow-sm player-card">
              <img src="${av}" class="card-img-top rounded-circle mx-auto mt-3"
                   style="width:80px;height:80px;object-fit:cover"
                   alt="Avatar ${name}">
              <div class="card-body">
                <h5 class="card-title mb-1">${name}</h5>
                <a href="https://discord.com/users/${did}" target="_blank"
                   class="text-decoration-none small text-truncate d-block">
                  ${did}
                </a>
              </div>
            </div>
          </div>
        `);
      }
    }
    renderPagination();
  }

  function renderPagination() {
    pagUL.innerHTML = '';
    const pageCount = Math.ceil(filtered.length / perPage);
    function pageItem(i, label=i, disabled=false, active=false) {
      return `<li class="page-item ${disabled?'disabled':''} ${active?'active':''}">
        <a class="page-link" href="#" data-page="${i}">${label}</a>
      </li>`;
    }
    pagUL.insertAdjacentHTML('beforeend', pageItem(currentPage-1, '«', currentPage===1, false));
    for (let i = 1; i <= pageCount; i++) {
      pagUL.insertAdjacentHTML('beforeend', pageItem(i, i, false, i===currentPage));
    }
    pagUL.insertAdjacentHTML('beforeend', pageItem(currentPage+1, '»', currentPage===pageCount, false));
  }

  pagUL.addEventListener('click', e => {
    e.preventDefault();
    const a = e.target.closest('a.page-link');
    if (!a || a.parentNode.classList.contains('disabled')) return;
    const p = parseInt(a.dataset.page);
    if (p >=1 && p <= Math.ceil(filtered.length/perPage)) {
      currentPage = p;
      renderPage(currentPage);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });

  search.addEventListener('input', () => {
    const q = search.value.toLowerCase();
    filtered = rows.filter(u =>
      u.display_name.toLowerCase().includes(q)
    );
    currentPage = 1;
    renderPage(currentPage);
  });

  // efect hover
  document.head.insertAdjacentHTML('beforeend', `
    <style>
      .player-card:hover { transform: translateY(-4px); transition: .2s; }
      .player-card { transition: .2s; }
    </style>
  `);

  // inițial
  renderPage(1);
})();
</script>
