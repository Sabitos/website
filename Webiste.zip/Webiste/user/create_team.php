<?php
// public_html/user/create_team.php

require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) redirect(BASE_URL);

$pdo  = Database::getInstance()->getConnection();
$user = fetchUserByDiscordId($_SESSION['user']['discord_id']);

// 1) Verific dacă există deja o echipă unde e captain
$stmt = $pdo->prepare("SELECT * FROM teams WHERE captain_id = :uid LIMIT 1");
$stmt->execute(['uid' => $user['id']]);
$ownTeam = $stmt->fetch();

if ($ownTeam) {
    // dacă există, nu poate crea alta
    include __DIR__ . '/../includes/header.php';
    include __DIR__ . '/../includes/navbar.php';
    echo '<div class="container py-5">';
    echo '<div class="alert alert-info">Ești deja căpitan al echipei <strong>'
         . sanitize($ownTeam['name'])
         . "</strong>. <a href=\"team.php?id={$ownTeam['id']}\">Vezi echipa</a>.</div>";
    echo '</div>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}

// 2) Restul verificărilor de permisiuni
if (empty($user['riot_id'])) {
    die('<div class="alert alert-danger m-4">Trebuie să ai Riot ID setat ca să creezi echipă.</div>');
}
$allowed = ['Radiant','Immortal'];
if (!isAdmin() && !in_array($user['current_rank'] ?? '', $allowed, true)) {
    die('<div class="alert alert-warning m-4">Doar Radiant, Immortal sau administratorii pot crea echipe.</div>');
}

// 3) Dacă s‑a trimis formularul
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    $teamName = trim(getPost('team_name'));
    if ($teamName === '') {
        $error = 'Numele echipei nu poate fi gol.';
    } else {
        $check = $pdo->prepare("SELECT 1 FROM teams WHERE `name` = :nm");
        $check->execute(['nm'=>$teamName]);
        if ($check->fetchColumn()) {
            $error = 'Există deja o echipă cu acest nume.';
        } else {
            $ins = $pdo->prepare("
              INSERT INTO teams (`name`, captain_id, created_at)
              VALUES (:nm, :cap, NOW())
            ");
            $ins->execute([
              'nm'  => $teamName,
              'cap' => $user['id']
            ]);
            $teamId = $pdo->lastInsertId();
            redirect(BASE_URL . "/user/team.php?id={$teamId}");
        }
    }
}

// 4) Afișez formularul
$pageTitle = 'Creează echipă – VOSZ';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0"><i class="bi bi-people-fill me-2"></i>Creează echipă</h5>
        </div>
        <div class="card-body">
          <?php if ($error): ?>
            <div class="alert alert-danger"><?= sanitize($error) ?></div>
          <?php endif; ?>
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <div class="mb-3">
              <label for="team_name" class="form-label">Nume echipă</label>
              <input
                type="text"
                id="team_name"
                name="team_name"
                class="form-control"
                placeholder="Ex: Phoenix Rising"
                required>
            </div>
            <button class="btn btn-success w-100">
              <i class="bi bi-check2-circle me-1"></i>Crează echipă
            </button>
          </form>
        </div>
        <div class="card-footer text-muted small">
          Doar Radiant, Immortal sau administratorii pot crea echipe.
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
