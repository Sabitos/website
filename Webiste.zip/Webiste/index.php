<?php
// public_html/index.php
require_once __DIR__ . '/includes/functions.php';
$pdo = Database::getInstance()->getConnection();

// verificăm dacă există tabel/results pentru statistici
$hasStats = (bool)$pdo->query("
  SHOW TABLES LIKE 'match_results'
")->fetchColumn();

// Top 10 jucători: fie după winrate (dacă există), fie după data creării
if ($hasStats) {
  // presupunem că match_results are coloanele user_id, is_win
  $topPlayers = $pdo->query("
    SELECT 
      u.display_name,
      SUM(m.is_win) AS wins,
      COUNT(*) - SUM(m.is_win) AS losses,
      ROUND(SUM(m.is_win)/COUNT(*)*100,1) AS winrate
    FROM match_results m
    JOIN users u ON u.id = m.user_id
    GROUP BY m.user_id
    HAVING COUNT(*) >= 1
    ORDER BY winrate DESC, wins DESC
    LIMIT 10
  ")->fetchAll(PDO::FETCH_ASSOC);
} else {
  $topPlayers = $pdo->query("
    SELECT display_name
    FROM users
    ORDER BY created_at DESC
    LIMIT 10
  ")->fetchAll(PDO::FETCH_ASSOC);
}

// La fel, top echipe (dacă ai team_results)
if ($hasStats) {
  $topTeams = $pdo->query("
    SELECT 
      t.name,
      SUM(tr.is_win) AS wins,
      COUNT(*) - SUM(tr.is_win) AS losses,
      ROUND(SUM(tr.is_win)/COUNT(*)*100,1) AS winrate
    FROM team_results tr
    JOIN teams t ON t.id = tr.team_id
    GROUP BY tr.team_id
    HAVING COUNT(*) >= 1
    ORDER BY winrate DESC, wins DESC
    LIMIT 10
  ")->fetchAll(PDO::FETCH_ASSOC);
} else {
  $topTeams = $pdo->query("
    SELECT name
    FROM teams
    ORDER BY created_at DESC
    LIMIT 10
  ")->fetchAll(PDO::FETCH_ASSOC);
}

$pageTitle = 'VOSZ Valorant Tournaments';
include __DIR__. '/includes/header.php';
include __DIR__. '/includes/navbar.php';
?>

<div class="bg-dark text-light py-5">
  <div class="container text-center">
    <i class="bi bi-trophy" style="font-size:3rem;color:gold"></i>
    <h1 class="mt-3">VOSZ Valorant Tournaments</h1>
    <p class="lead">
      Bine ai venit pe platforma oficială a turneelor VOSZ!<br>
      Autentifică‑te cu Discord ca să‑ți administrezi echipele,<br>
      să primești invitații și să participi în competiții.
    </p>
    <?php if (isLoggedIn()): ?>
      <a href="<?= BASE_URL ?>/user/dashboard.php" class="btn btn-success btn-lg me-2">
        <i class="bi bi-speedometer2 me-1"></i>Dashboard
      </a>
    <?php else: ?>
      <a href="<?= BASE_URL ?>/login.php" class="btn btn-primary btn-lg me-2">
        <i class="bi bi-box-arrow-in-right me-1"></i>Login with Discord
      </a>
    <?php endif; ?>
    <a href="https://discord.gg/yourInvite" class="btn btn-outline-light btn-lg">
      <i class="bi bi-discord me-1"></i>Alătură-te Discord
    </a>
  </div>
</div>

<div class="container py-5">
  <div class="row gy-5">
    <!-- Top Jucători -->
    <div class="col-lg-6">
      <h2><i class="bi bi-people-fill me-1"></i>Top 10 Jucători</h2>
      <ul class="list-group">
        <?php if ($hasStats): ?>
          <?php foreach ($topPlayers as $p): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <div>
                <strong><?= sanitize($p['display_name']) ?></strong>
                <small class="text-muted">(
                  W:<?= $p['wins'] ?>,
                  L:<?= $p['losses'] ?>)</small>
              </div>
              <span class="badge bg-primary rounded-pill"><?= $p['winrate'] ?>%</span>
            </li>
          <?php endforeach; ?>
        <?php else: ?>
          <li class="list-group-item text-muted">Statistici indisponibile. Afișare după data creării:</li>
          <?php foreach ($topPlayers as $p): ?>
            <li class="list-group-item"><?= sanitize($p['display_name']) ?></li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>

    <!-- Top Echipe -->
    <div class="col-lg-6">
      <h2><i class="bi bi-people-lines-fill me-1"></i>Top 10 Echipe</h2>
      <ul class="list-group">
        <?php if ($hasStats): ?>
          <?php foreach ($topTeams as $t): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <div>
                <strong><?= sanitize($t['name']) ?></strong>
                <small class="text-muted">(
                  W:<?= $t['wins'] ?>,
                  L:<?= $t['losses'] ?>)</small>
              </div>
              <span class="badge bg-success rounded-pill"><?= $t['winrate'] ?>%</span>
            </li>
          <?php endforeach; ?>
        <?php else: ?>
          <li class="list-group-item text-muted">Statistici indisponibile. Afișare după data creării:</li>
          <?php foreach ($topTeams as $t): ?>
            <li class="list-group-item"><?= sanitize($t['name']) ?></li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</div>

<?php include __DIR__. '/includes/footer.php'; ?>
