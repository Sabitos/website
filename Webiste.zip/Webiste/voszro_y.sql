-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Gazdă: localhost:3306
-- Timp de generare: iul. 26, 2025 la 07:10 PM
-- Versiune server: 8.0.42-cll-lve
-- Versiune PHP: 8.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `voszro_y`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `admins`
--

CREATE TABLE `admins` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Eliminarea datelor din tabel `admins`
--

INSERT INTO `admins` (`id`, `user_id`, `role`) VALUES
(2, 3, 'admin');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `logs`
--

CREATE TABLE `logs` (
  `id` int NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `rank_requests`
--

CREATE TABLE `rank_requests` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `profile_url` varchar(255) NOT NULL,
  `rank_name` varchar(50) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `submitted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_by` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Eliminarea datelor din tabel `rank_requests`
--

INSERT INTO `rank_requests` (`id`, `user_id`, `profile_url`, `rank_name`, `image_path`, `status`, `submitted_at`, `reviewed_by`, `reviewed_at`) VALUES
(2, 3, 'https://tracker.gg/valorant/profile/riot/noMercy%23noNoy/overview?platform=pc&playlist=competitive&season=ac12e9b3-47e6-9599-8fa1-0bb473e5efc7', 'Platina', 'uploads/ranks/3_1753538134.png', '', '2025-07-26 16:55:34', 3, '2025-07-26 16:55:40'),
(3, 4, 'https://tracker.gg/valorant/profile/riot/MSD90%23MSD/overview?platform=pc&playlist=competitive&season=ac12e9b3-47e6-9599-8fa1-0bb473e5efc7', 'Gold', 'uploads/ranks/4_1753539613.png', '', '2025-07-26 17:20:13', 3, '2025-07-26 17:20:18');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `registrations`
--

CREATE TABLE `registrations` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `tournament_id` int DEFAULT NULL,
  `registered_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `teams`
--

CREATE TABLE `teams` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wins` int UNSIGNED NOT NULL DEFAULT '0',
  `losses` int UNSIGNED NOT NULL DEFAULT '0',
  `captain_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Eliminarea datelor din tabel `teams`
--

INSERT INTO `teams` (`id`, `name`, `wins`, `losses`, `captain_id`, `created_at`) VALUES
(3, 'God Slayer', 0, 0, 3, '2025-07-26 16:55:01');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `team_invites`
--

CREATE TABLE `team_invites` (
  `id` int NOT NULL,
  `team_id` int NOT NULL,
  `user_id` int NOT NULL,
  `invited_by` int NOT NULL,
  `status` enum('pending','accepted','declined') COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `responded_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Eliminarea datelor din tabel `team_invites`
--

INSERT INTO `team_invites` (`id`, `team_id`, `user_id`, `invited_by`, `status`, `created_at`, `responded_at`) VALUES
(2, 3, 4, 3, 'accepted', '2025-07-26 17:29:14', '2025-07-26 17:29:18');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `team_members`
--

CREATE TABLE `team_members` (
  `id` int NOT NULL,
  `team_id` int NOT NULL,
  `user_id` int NOT NULL,
  `position` enum('Captain','Ascendant','Diamond','Platinum','Gold') COLLATE utf8mb3_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Eliminarea datelor din tabel `team_members`
--

INSERT INTO `team_members` (`id`, `team_id`, `user_id`, `position`) VALUES
(3, 3, 4, '');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `tournaments`
--

CREATE TABLE `tournaments` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `start_date` date DEFAULT NULL,
  `status` enum('upcoming','ongoing','finished') DEFAULT 'upcoming'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `discord_id` varchar(32) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `discriminator` varchar(10) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `roles` json DEFAULT NULL,
  `display_name` varchar(100) DEFAULT NULL,
  `current_rank` enum('Iron','Bronze','Silver','Gold','Platinum','Diamond','Ascendant','Immortal','Radiant') NOT NULL DEFAULT 'Iron',
  `wins` int UNSIGNED NOT NULL DEFAULT '0',
  `losses` int UNSIGNED NOT NULL DEFAULT '0',
  `riot_id` varchar(100) DEFAULT NULL,
  `tiktok_handle` varchar(100) DEFAULT NULL,
  `twitch_handle` varchar(100) DEFAULT NULL,
  `youtube_handle` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `rank_status` enum('none','pending','approved','rejected') NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Eliminarea datelor din tabel `users`
--

INSERT INTO `users` (`id`, `discord_id`, `username`, `discriminator`, `avatar`, `email`, `roles`, `display_name`, `current_rank`, `wins`, `losses`, `riot_id`, `tiktok_handle`, `twitch_handle`, `youtube_handle`, `created_at`, `last_login`, `rank_status`) VALUES
(3, '603862126838415371', 'gssabit0', '0', '4d8ce557fa44aef4340809b04041a0bf', 'zerefdragneel55@yahoo.com', 'null', 'GSゝSabit0', 'Platinum', 0, 0, 'Sabit0#Sabit', '@gssabit0', '@gsnomercy', '@GSSabit0', '2025-07-26 16:04:49', '2025-07-26 16:04:49', 'approved'),
(4, '673882802256871455', 'msd.90', '0', '5a3d2ee121b8154067fe3da9b1e5237e', 'mihalachesebastiandumitru.sm@gmail.com', '[]', NULL, 'Gold', 0, 0, 'MSD90#MSD', '', '', '', '2025-07-26 17:18:33', '2025-07-26 17:18:33', 'approved');

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexuri pentru tabele `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexuri pentru tabele `rank_requests`
--
ALTER TABLE `rank_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `reviewed_by` (`reviewed_by`);

--
-- Indexuri pentru tabele `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_reg` (`user_id`,`tournament_id`),
  ADD KEY `tournament_id` (`tournament_id`);

--
-- Indexuri pentru tabele `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `captain_id` (`captain_id`);

--
-- Indexuri pentru tabele `team_invites`
--
ALTER TABLE `team_invites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `invited_by` (`invited_by`);

--
-- Indexuri pentru tabele `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_id` (`team_id`,`position`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexuri pentru tabele `tournaments`
--
ALTER TABLE `tournaments`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `discord_id` (`discord_id`);

--
-- AUTO_INCREMENT pentru tabele eliminate
--

--
-- AUTO_INCREMENT pentru tabele `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pentru tabele `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `rank_requests`
--
ALTER TABLE `rank_requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pentru tabele `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pentru tabele `team_invites`
--
ALTER TABLE `team_invites`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pentru tabele `team_members`
--
ALTER TABLE `team_members`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pentru tabele `tournaments`
--
ALTER TABLE `tournaments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constrângeri pentru tabele eliminate
--

--
-- Constrângeri pentru tabele `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constrângeri pentru tabele `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constrângeri pentru tabele `rank_requests`
--
ALTER TABLE `rank_requests`
  ADD CONSTRAINT `rank_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rank_requests_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `admins` (`user_id`) ON DELETE SET NULL;

--
-- Constrângeri pentru tabele `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `registrations_ibfk_2` FOREIGN KEY (`tournament_id`) REFERENCES `tournaments` (`id`) ON DELETE CASCADE;

--
-- Constrângeri pentru tabele `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`captain_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constrângeri pentru tabele `team_invites`
--
ALTER TABLE `team_invites`
  ADD CONSTRAINT `team_invites_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `team_invites_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `team_invites_ibfk_3` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constrângeri pentru tabele `team_members`
--
ALTER TABLE `team_members`
  ADD CONSTRAINT `team_members_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`),
  ADD CONSTRAINT `team_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
