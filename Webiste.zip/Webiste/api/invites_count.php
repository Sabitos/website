<?php
// public_html/api/invites_count.php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn()) {
    echo json_encode(['count'=>0]);
    exit;
}

$pdo = Database::getInstance()->getConnection();
$stmt = $pdo->prepare("
  SELECT COUNT(*) AS cnt
  FROM team_invites
  WHERE user_id = :uid
    AND responded_at IS NULL
");
$stmt->execute(['uid'=>$_SESSION['user']['id']]);
$count = (int)$stmt->fetchColumn();

echo json_encode(['count'=>$count]);
