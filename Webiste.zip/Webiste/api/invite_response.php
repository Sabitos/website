<?php
// public_html/api/invite_response.php
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error'=>'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$inviteId = intval($input['invite_id'] ?? 0);
$accept   = !empty($input['accept']);

$pdo = Database::getInstance()->getConnection();

// verificăm că invitația există și i se adresează utilizatorului
$stmt = $pdo->prepare("
  SELECT 1 FROM team_invites
  WHERE id = :iid
    AND user_id = :uid
    AND responded_at IS NULL
");
$stmt->execute([
  'iid' => $inviteId,
  'uid' => $_SESSION['user']['id']
]);
if (!$stmt->fetchColumn()) {
    http_response_code(404);
    echo json_encode(['error'=>'Invite not found']);
    exit;
}

if ($accept) {
    // marchează acceptat
    $pdo->prepare("
      UPDATE team_invites
      SET accepted_at = NOW(), responded_at = NOW()
      WHERE id = :iid
    ")->execute(['iid'=>$inviteId]);

    // adaugă în team_members
    // aflăm echipa
    $tid = $pdo->prepare("SELECT team_id FROM team_invites WHERE id = :iid");
    $tid->execute(['iid'=>$inviteId]);
    $teamId = $tid->fetchColumn();

    $pdo->prepare("
      INSERT INTO team_members(team_id,user_id,position)
      VALUES(:tid,:uid,'Member')
    ")->execute([
      'tid'=>$teamId,
      'uid'=>$_SESSION['user']['id']
    ]);
} else {
    // marchează respins
    $pdo->prepare("
      UPDATE team_invites
      SET responded_at = NOW()
      WHERE id = :iid
    ")->execute(['iid'=>$inviteId]);
}

echo json_encode(['success'=>true]);
