<?php
// includes/functions.php

session_start();
require_once __DIR__ . '/config.php'; // definește DB_HOST, DB_NAME, DB_USER, DB_PASS etc.

/**
 * Singleton PDO wrapper.
 */
class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $this->pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection(): PDO {
        return $this->pdo;
    }
}

/**
 * Escape HTML; acceptă și null.
 */
function sanitize($str): string {
    return htmlspecialchars((string)$str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Token / verificare CSRF.
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function check_csrf(): void {
    if (
        empty($_POST['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        http_response_code(400);
        die('CSRF validation failed');
    }
}

/**
 * Preia $_POST curățat / filtrat.
 */
function getPost(string $key, $filter = FILTER_DEFAULT) {
    $val = $_POST[$key] ?? null;
    if ($val === null) return null;
    if ($filter !== FILTER_DEFAULT) {
        return filter_var($val, $filter) ?: null;
    }
    return trim($val);
}

/**
 * Redirect rapid.
 */
function redirect(string $url): void {
    header("Location: {$url}");
    exit;
}

/**
 * Login check.
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user']);
}

/**
 * Preia date user după Discord ID.
 */
function fetchUserByDiscordId(string $discord_id): array {
    $pdo = Database::getInstance()->getConnection();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE discord_id = :did LIMIT 1");
    $stmt->execute(['did' => $discord_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
}

/**
 * Upsert utilizator din Discord payload.
 */
function upsertUser(array $data): bool {
    $pdo = Database::getInstance()->getConnection();
    $exists = fetchUserByDiscordId($data['id']);
    $roles_json = json_encode($data['roles'] ?? []);
    if ($exists) {
        $stmt = $pdo->prepare("
            UPDATE users SET
              username = :un,
              discriminator = :disc,
              avatar = :av,
              email = :em,
              roles = :rl,
              last_login = NOW()
            WHERE discord_id = :did
        ");
        return $stmt->execute([
            'un'   => $data['username'],
            'disc' => $data['discriminator'],
            'av'   => $data['avatar'] ?? null,
            'em'   => $data['email'] ?? null,
            'rl'   => $roles_json,
            'did'  => $data['id'],
        ]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO users
              (discord_id, username, discriminator, avatar, email, roles, created_at, last_login)
            VALUES
              (:did, :un, :disc, :av, :em, :rl, NOW(), NOW())
        ");
        return $stmt->execute([
            'did'  => $data['id'],
            'un'   => $data['username'],
            'disc' => $data['discriminator'],
            'av'   => $data['avatar'] ?? null,
            'em'   => $data['email'] ?? null,
            'rl'   => $roles_json,
        ]);
    }
}

/**
 * Verifică admin.
 */
function isAdmin(): bool {
    if (!isLoggedIn()) return false;
    $pdo = Database::getInstance()->getConnection();
    $stmt = $pdo->prepare("SELECT 1 FROM admins WHERE user_id = :uid LIMIT 1");
    $stmt->execute(['uid' => $_SESSION['user']['id']]);
    return (bool)$stmt->fetchColumn();
}

/**
 * Extrage categoria de rank (ex. "Platinum" din "Platinum 2").
 */
function getRankCategory(string $fullRank): string {
    $parts = explode(' ', trim($fullRank), 2);
    return ucfirst(strtolower($parts[0]));
}

/**
 * Află echipa unui utilizator (căpitan sau membru) sau null.
 */
function fetchUserTeam(int $userId): ?array {
    $pdo = Database::getInstance()->getConnection();
    $stmt = $pdo->prepare("
      SELECT t.id, t.name
      FROM teams t
      WHERE t.captain_id = :uid
      UNION
      SELECT t.id, t.name
      FROM teams t
      JOIN team_members tm ON tm.team_id = t.id
      WHERE tm.user_id = :uid
      LIMIT 1
    ");
    $stmt->execute(['uid' => $userId]);
    $team = $stmt->fetch(PDO::FETCH_ASSOC);
    return $team ?: null;
}
