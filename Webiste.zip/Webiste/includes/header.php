<?php
// includes/header.php
?>
<!-- Bootstrap CSS (fără integrity) -->
<link
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  rel="stylesheet">
<!-- Bootstrap Icons -->
<link
  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
  rel="stylesheet">
<!-- Favicon -->
<link rel="icon" href="<?= BASE_URL ?>/favicon.ico">
