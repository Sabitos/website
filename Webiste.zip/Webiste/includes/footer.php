<?php
// includes/footer.php
?>
<footer class="bg-dark text-light py-3 mt-5">
  <div class="container text-center">
    <small>&copy; <?= date('Y') ?> VOSZ. Toate drepturile rezervate.</small>
  </div>
</footer>

<!-- Bootstrap Bundle JS (fără integrity) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Script UI -->
<script src="<?= BASE_URL ?>/assets/js/script.js"></script>

<?php if (isLoggedIn()): ?>
<script>
// Funcție care interoghează API-ul și actualizează badge-ul de invitații
async function updateInvitesCount() {
  try {
    const res = await fetch('<?= BASE_URL ?>/api/invites_count.php');
    if (!res.ok) return;
    const { count } = await res.json();
    const badge = document.getElementById('invitesBadge');
    if (!badge) return;
    if (count > 0) {
      badge.textContent = count;
      badge.classList.remove('d-none');
    } else {
      badge.classList.add('d-none');
    }
  } catch (e) {
    console.error('Invite badge error', e);
  }
}

// Actualizează la încărcare și la fiecare 30s
document.addEventListener('DOMContentLoaded', updateInvitesCount);
setInterval(updateInvitesCount, 30000);
</script>
<?php endif; ?>

</body>
</html>
