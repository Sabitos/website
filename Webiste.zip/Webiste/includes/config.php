<?php
// =======================
// DATABASE CONFIG
// =======================
define('DB_HOST', 'localhost');
define('DB_NAME', 'voszro_y');
define('DB_USER', 'voszro_yzx');
define('DB_PASS', '{ImXyrSE*2!KGnsR');

// =======================
// DISCORD API CONFIG
// =======================
define('DISCORD_CLIENT_ID', '1392484898824126524');
define('DISCORD_CLIENT_SECRET', '3jgK0D9TCym6ySqcmlKh8Phg6KQsNLOi');
define('DISCORD_REDIRECT_URI', 'https://vosz.ro/oauth/callback.php');

// Discord Guild ID (pentru verificare dacă userul este pe serverul tău)
define('DISCORD_GUILD_ID', '1305925400186322974');

// =======================
// TRACKER.GG API CONFIG
// =======================
define('TRACKER_API_KEY', '4d21e0f8-65f3-4529-821c-d316dc63e0a5');
define('TRACKER_API_BASE', 'https://public-api.tracker.gg/v2/valorant/standard/profile/riot/');

// =======================
// SITE URL BASE
// =======================
define('BASE_URL', 'https://vosz.ro');

// =======================
// DATABASE CONNECTION (PDO)
// =======================
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
