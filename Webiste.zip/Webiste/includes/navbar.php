<?php
// includes/navbar.php
require_once __DIR__ . '/functions.php';

$userLoggedIn = isLoggedIn();
$user         = $_SESSION['user'] ?? [];
$did          = $user['discord_id']    ?? '';
$av           = $user['avatar']        ?? '';
$disc         = intval($user['discriminator'] ?? 0);

// URL avatar (Discord sau fallback)
if ($av) {
    $avatarUrl = "https://cdn.discordapp.com/avatars/{$did}/{$av}.png";
} else {
    $avatarUrl = "https://cdn.discordapp.com/embed/avatars/" . ($disc % 5) . ".png";
}
$avatarUrl   = sanitize($avatarUrl);
$displayName = sanitize($user['display_name'] ?? $user['username'] ?? 'User');

// Echipa curentă (dacă e logat)
$team = $userLoggedIn ? fetchUserTeam((int)$user['id']) : null;
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="<?= BASE_URL ?>">
      <i class="bi bi-trophy-fill me-2"></i>VOSZ
    </a>
    <button class="navbar-toggler" type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mainNav"
            aria-controls="mainNav"
            aria-expanded="false"
            aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-center">
        <?php if (!$userLoggedIn): ?>
          <li class="nav-item">
            <a class="nav-link d-flex align-items-center" href="<?= BASE_URL ?>/login.php">
              <i class="bi bi-box-arrow-in-right me-1"></i>Login with Discord
            </a>
          </li>
          <li class="nav-item me-3">
            <a class="btn btn-outline-light d-flex align-items-center" href="<?= BASE_URL ?>/user/players.php">
              <i class="bi bi-people-fill me-1"></i>Membri
            </a>
          </li>
        <?php else: ?>
          <!-- Echipa / Crează echipă -->
          <li class="nav-item me-3">
            <?php if ($team): ?>
              <a class="btn btn-outline-light d-flex align-items-center"
                 href="<?= BASE_URL ?>/user/team.php?id=<?= sanitize($team['id']) ?>">
                <i class="bi bi-people-fill me-1"></i><?= sanitize($team['name']) ?>
              </a>
            <?php else: ?>
              <a class="btn btn-outline-success d-flex align-items-center"
                 href="<?= BASE_URL ?>/user/create_team.php">
                <i class="bi bi-person-plus me-1"></i>Crează echipă
              </a>
            <?php endif; ?>
          </li>

          <!-- Invitații -->
          <li class="nav-item me-3">
            <a class="btn btn-outline-light position-relative"
               href="<?= BASE_URL ?>/user/invites.php">
              <i class="bi bi-envelope me-1"></i>Invitații
              <span id="invitesBadge"
                    class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">
                0
              </span>
            </a>
          </li>

          <!-- Membri -->
          <li class="nav-item me-3">
            <a class="btn btn-outline-light d-flex align-items-center" href="<?= BASE_URL ?>/user/players.php">
              <i class="bi bi-people-fill me-1"></i>Membri
            </a>
          </li>

          <!-- Profil dropdown -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle d-flex align-items-center"
               href="#" id="userDropdown" role="button"
               data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?= $avatarUrl ?>" alt="Avatar"
                   class="rounded-circle me-2" width="32" height="32">
              <span><?= $displayName ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm"
                aria-labelledby="userDropdown">
              <?php if (isAdmin()): ?>
                <li>
                  <a class="dropdown-item d-flex align-items-center"
                     href="<?= BASE_URL ?>/admin/index.php">
                    <i class="bi bi-speedometer2 me-2"></i>Admin CP
                  </a>
                </li>
                <li><hr class="dropdown-divider"></li>
              <?php endif; ?>
              <li>
                <a class="dropdown-item d-flex align-items-center"
                   href="<?= BASE_URL ?>/user/profile.php">
                  <i class="bi bi-person-circle me-2"></i>Profile
                </a>
              </li>
              <li><hr class="dropdown-divider"></li>
              <li>
                <a class="dropdown-item d-flex align-items-center"
                   href="<?= BASE_URL ?>/logout.php">
                  <i class="bi bi-box-arrow-right me-2"></i>Logout
                </a>
              </li>
            </ul>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<?php if ($userLoggedIn): ?>
<script>
// Actualizează badge-ul de invitații la load și la fiecare 30s
async function updateInvitesBadge() {
  try {
    const res = await fetch('<?= BASE_URL ?>/api/invites_count.php');
    if (!res.ok) return;
    const {count} = await res.json();
    const badge = document.getElementById('invitesBadge');
    if (count > 0) {
      badge.textContent = count;
      badge.classList.remove('d-none');
    } else {
      badge.classList.add('d-none');
    }
  } catch (e) {
    console.error('Invite badge error', e);
  }
}
document.addEventListener('DOMContentLoaded', () => {
  updateInvitesBadge();
  setInterval(updateInvitesBadge, 30000);
});
</script>
<?php endif; ?>
