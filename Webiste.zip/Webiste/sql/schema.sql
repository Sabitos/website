CREATE DATABASE IF NOT EXISTS vosz_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE vosz_db;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  discord_id VARCHAR(32) NOT NULL UNIQUE,
  username VARCHAR(100),
  discriminator VARCHAR(10),
  avatar VARCHAR(255),
  email VARCHAR(255),
  roles JSON,
  display_name VARCHAR(100) DEFAULT NULL,
  riot_id VARCHAR(100) DEFAULT NULL,
  created_at DATETIME,
  last_login DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
