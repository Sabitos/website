<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isAdmin()) {
    redirect(BASE_URL);
}

$pdo = Database::getInstance()->getConnection();

// Procesăm ban/unban
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $userId = getPost('uid', FILTER_SANITIZE_NUMBER_INT);
    $action = getPost('action', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    if ($userId !== null && in_array($action, ['ban', 'unban'], true)) {
        $roles = $action === 'ban'
            ? json_encode(['banned'], JSON_THROW_ON_ERROR)
            : json_encode([], JSON_THROW_ON_ERROR);
        $stmt = $pdo->prepare("UPDATE users SET roles = :roles WHERE id = :uid");
        $stmt->execute([
            'roles' => $roles,
            'uid'   => $userId
        ]);
    }

    redirect(BASE_URL . '/admin/users.php');
}

$users = $pdo
    ->query("SELECT * FROM users ORDER BY created_at DESC")
    ->fetchAll();
?>
<!doctype html>
<html lang="ro">
<head>
    <?php
    $pageTitle = 'Gestionare Utilizatori – Admin';
    include __DIR__ . '/../includes/header.php';
    ?>
</head>
<body class="bg-light">
<?php include __DIR__ . '/../includes/navbar.php'; ?>

<div class="container py-4">
  <h2>Utilizatori Înregistrați</h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>#</th><th>Discord</th><th>Email</th><th>Roluri</th><th>Acțiuni</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($users as $u): ?>
      <tr>
        <td><?= sanitize((string)$u['id']) ?></td>
        <td><?= sanitize($u['username'].'#'.$u['discriminator']) ?></td>
        <td><?= sanitize($u['email']) ?></td>
        <td><?= sanitize(implode(', ', json_decode($u['roles'], true))) ?></td>
        <td>
          <form method="post" class="d-inline">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="uid"        value="<?= sanitize((string)$u['id']) ?>">
            <?php if (!in_array('banned', json_decode($u['roles'], true), true)): ?>
              <button name="action" value="ban"   class="btn btn-sm btn-danger">Ban</button>
            <?php else: ?>
              <button name="action" value="unban" class="btn btn-sm btn-success">Unban</button>
            <?php endif; ?>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
