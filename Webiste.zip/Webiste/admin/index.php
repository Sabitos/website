<?php
// public_html/admin/index.php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) {
  redirect(BASE_URL);
}

$pdo = Database::getInstance()->getConnection();

// 1) Statistici
$totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalTeams = (int)$pdo->query("SELECT COUNT(*) FROM teams")->fetchColumn();
$pendingRank = (int)$pdo->query("SELECT COUNT(*) FROM rank_requests WHERE status = 'pending'")->fetchColumn();
$pendingInvites = (int)$pdo->prepare("SELECT COUNT(*) FROM team_invites WHERE accepted_at IS NULL")->fetchColumn();

// 2) Pagina
$pageTitle = 'Admin Panel';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container py-5">
  <h1 class="mb-4">Admin Panel</h1>

  <!-- Statistici rapide -->
  <div class="row g-4 mb-5">
    <div class="col-md-3">
      <div class="card text-white bg-primary h-100">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-people-fill display-4 me-3"></i>
          <div>
            <h5 class="card-title">Utilizatori</h5>
            <h2 class="card-text"><?= $totalUsers ?></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-white bg-success h-100">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-people me-3 display-4"></i>
          <div>
            <h5 class="card-title">Echipe</h5>
            <h2 class="card-text"><?= $totalTeams ?></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-white bg-warning h-100">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-award display-4 me-3"></i>
          <div>
            <h5 class="card-title">Rank pending</h5>
            <h2 class="card-text"><?= $pendingRank ?></h2>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card text-white bg-danger h-100">
        <div class="card-body d-flex align-items-center">
          <i class="bi bi-envelope-paper display-4 me-3"></i>
          <div>
            <h5 class="card-title">Invitații</h5>
            <h2 class="card-text"><?= $pendingInvites ?></h2>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Acțiuni Admin -->
  <div class="row g-4">
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-header">
          <i class="bi bi-people-fill me-1"></i>Gestionare Utilizatori
        </div>
        <div class="card-body">
          <p class="card-text">
            Vezi lista utilizatorilor înregistrați, acordă roluri, blochează/deblochează conturi.
          </p>
          <a href="<?= BASE_URL ?>/admin/users.php" class="btn btn-primary w-100">Deschide</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-header">
          <i class="bi bi-trophy-fill me-1"></i>Gestionare Turnee
        </div>
        <div class="card-body">
          <p class="card-text">
            Creează, editează sau șterge turnee. Setează descriere, date și starea.
          </p>
          <a href="<?= BASE_URL ?>/admin/tournaments.php" class="btn btn-primary w-100">Deschide</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-header">
          <i class="bi bi-award me-1"></i>Cereri Verificare Rank
        </div>
        <div class="card-body">
          <p class="card-text">
            Vezi toate cererile de verificare rank, aprobă sau respinge.
          </p>
          <a href="<?= BASE_URL ?>/admin/rank_requests.php" class="btn btn-primary w-100">Deschide</a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
