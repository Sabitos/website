<?php
// public_html/admin/tournaments.php
require_once __DIR__ . '/../includes/functions.php';
if (!isAdmin()) redirect(BASE_URL);

$pdo = Database::getInstance()->getConnection();

// POST: create / edit / delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    // Create
    if (getPost('create_tourney') !== null) {
        $stmt = $pdo->prepare("
          INSERT INTO tournaments (name,description,start_date,status)
          VALUES (:n,:d,:sd,:st)
        ");
        $stmt->execute([
          'n'=>getPost('name'),
          'd'=>getPost('description'),
          'sd'=>getPost('start_date'),
          'st'=>getPost('status')
        ]);
    }
    // Edit
    if (getPost('edit_tourney') !== null) {
        $stmt = $pdo->prepare("
          UPDATE tournaments
          SET name=:n, description=:d, start_date=:sd, status=:st
          WHERE id=:id
        ");
        $stmt->execute([
          'n'=>getPost('name'),
          'd'=>getPost('description'),
          'sd'=>getPost('start_date'),
          'st'=>getPost('status'),
          'id'=>getPost('edit_tourney')
        ]);
    }
    // Delete
    if (getPost('delete_tourney') !== null) {
        $pdo->prepare("DELETE FROM tournaments WHERE id=:id")
            ->execute(['id'=>getPost('delete_tourney')]);
    }
    redirect(BASE_URL.'/admin/tournaments.php');
}

// Preluare turnee
$tours = $pdo->query("SELECT * FROM tournaments ORDER BY start_date DESC")->fetchAll();
$pageTitle = 'Gestionare Turnee – Admin';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container py-4">
  <h1 class="mb-4">Gestionare Turnee</h1>
  <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#createModal">
    <i class="bi bi-plus-circle me-1"></i>Adaugă Turneu
  </button>

  <table class="table table-bordered table-hover align-middle">
    <thead>
      <tr>
        <th>#</th><th>Nume</th><th>Start</th><th>Status</th><th>Acțiuni</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($tours as $t): ?>
      <tr>
        <td><?= $t['id'] ?></td>
        <td><?= sanitize($t['name']) ?></td>
        <td><?= sanitize($t['start_date']) ?></td>
        <td><?= sanitize($t['status']) ?></td>
        <td>
          <!-- Edit -->
          <button
            class="btn btn-sm btn-outline-primary"
            data-bs-toggle="modal"
            data-bs-target="#editModal<?= $t['id'] ?>">
            Edit
          </button>
          <!-- Delete -->
          <form method="post" class="d-inline">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <button name="delete_tourney" value="<?= $t['id'] ?>"
                    class="btn btn-sm btn-outline-danger"
                    onclick="return confirm('Ștergi turneul?')">
              Delete
            </button>
          </form>
        </td>
      </tr>

      <!-- Edit Modal -->
      <div class="modal fade" id="editModal<?= $t['id'] ?>" tabindex="-1">
        <div class="modal-dialog">
          <form method="post" class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Edit Turneu #<?= $t['id'] ?></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body row g-3">
              <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
              <input type="hidden" name="edit_tourney" value="<?= $t['id'] ?>">
              <div class="col-12">
                <label class="form-label">Nume</label>
                <input type="text" name="name" class="form-control" required
                       value="<?= sanitize($t['name']) ?>">
              </div>
              <div class="col-12">
                <label class="form-label">Descriere</label>
                <textarea name="description" class="form-control" rows="3"><?= sanitize($t['description']) ?></textarea>
              </div>
              <div class="col-md-6">
                <label class="form-label">Data start</label>
                <input type="date" name="start_date" class="form-control" required
                       value="<?= sanitize($t['start_date']) ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                  <?php foreach (['upcoming','open','closed'] as $st): ?>
                    <option value="<?= $st ?>" <?= $t['status']===$st?'selected':'' ?>>
                      <?= ucfirst($st) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Adaugă Turneu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body row g-3">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <input type="hidden" name="create_tourney" value="1">
        <div class="col-12">
          <label class="form-label">Nume</label>
          <input type="text" name="name" class="form-control" required>
        </div>
        <div class="col-12">
          <label class="form-label">Descriere</label>
          <textarea name="description" class="form-control" rows="3"></textarea>
        </div>
        <div class="col-md-6">
          <label class="form-label">Data start</label>
          <input type="date" name="start_date" class="form-control" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <option value="upcoming">Upcoming</option>
            <option value="open">Open</option>
            <option value="closed">Closed</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Create</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
