<?php
require_once __DIR__.'/../includes/functions.php';
if (!isAdmin()) redirect(BASE_URL);

$pdo = Database::getInstance()->getConnection();

// Procesăm aprobări/reject
if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    $reqId = getPost('rid', FILTER_SANITIZE_NUMBER_INT);
    $action= getPost('action', FILTER_SANITIZE_FULL_SPECIAL_CHARS); // 'approve' sau 'reject'
    if ($reqId && in_array($action, ['approve','reject'], true)) {
        // 1. Actualizăm rank_requests.status și setăm reviewed_by/reviewed_at
        $stmt = $pdo->prepare("
          UPDATE rank_requests
          SET status = :st,
              reviewed_by = :admin,
              reviewed_at = NOW()
          WHERE id = :rid
        ");
        $stmt->execute([
          'st'    => $action,
          'admin' => $_SESSION['user']['id'],
          'rid'   => $reqId
        ]);
        // 2. Dacă aprobăm → actualizăm users.current_rank + rank_status
        if ($action==='approve') {
            // preluăm detalii cerere
            $r = $pdo->prepare("SELECT user_id, rank_name FROM rank_requests WHERE id = :rid");
            $r->execute(['rid'=>$reqId]);
            $row = $r->fetch();
            $u = $pdo->prepare("
              UPDATE users
              SET current_rank = :rn,
                  rank_status  = 'approved'
              WHERE id = :uid
            ");
            $u->execute([
              'rn'  => $row['rank_name'],
              'uid' => $row['user_id']
            ]);
        } else {
            // reject
            $r = $pdo->prepare("SELECT user_id FROM rank_requests WHERE id = :rid");
            $r->execute(['rid'=>$reqId]);
            $uid = $r->fetchColumn();
            $u = $pdo->prepare("UPDATE users SET rank_status='rejected' WHERE id = :uid");
            $u->execute(['uid'=>$uid]);
        }
    }
    redirect(BASE_URL.'/admin/rank_requests.php');
}

// Preluăm cereri
$reqs = $pdo->query("
  SELECT rr.*, u.username, u.discriminator
  FROM rank_requests rr
  JOIN users u ON u.id = rr.user_id
  ORDER BY rr.submitted_at DESC
")->fetchAll();
?>
<!doctype html>
<html lang="ro">
<head>
  <?php $pageTitle='Rank Requests – Admin'; include __DIR__.'/../includes/header.php'; ?>
</head>
<body class="bg-light">
<?php include __DIR__.'/../includes/navbar.php'; ?>

<div class="container py-4">
  <h2>Rank Verification Requests</h2>
  <table class="table">
    <thead>
      <tr>
        <th>#</th><th>User</th><th>Rank Request</th><th>Data</th><th>Imagine</th><th>Status</th><th>Acțiuni</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($reqs as $r): ?>
      <tr>
        <td><?= sanitize($r['id']) ?></td>
        <td><?= sanitize($r['username'].'#'.$r['discriminator']) ?></td>
        <td>
          <a href="<?= sanitize($r['profile_url']) ?>" target="_blank">
            <?= sanitize($r['rank_name']) ?>
          </a>
        </td>
        <td><?= sanitize($r['submitted_at']) ?></td>
        <td>
          <a href="<?= BASE_URL.'/assets/'.sanitize($r['image_path']) ?>" target="_blank">
            Vezi imagine
          </a>
        </td>
        <td><?= sanitize($r['status']) ?></td>
        <td>
          <?php if($r['status']==='pending'): ?>
          <form method="post" class="d-inline">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="rid" value="<?= sanitize($r['id']) ?>">
            <button name="action" value="approve" class="btn btn-sm btn-success">Approve</button>
          </form>
          <form method="post" class="d-inline">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="rid" value="<?= sanitize($r['id']) ?>">
            <button name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__.'/../includes/footer.php'; ?>
