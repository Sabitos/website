// Script inițial; se poate extinde ulterior
document.addEventListener('DOMContentLoaded', () => {
    console.log('VOSZ Valorant Tournaments loaded');
});
