<?php
require_once __DIR__ . '/../includes/functions.php';

$scope = 'identify email';
$url = 'https://discord.com/api/oauth2/authorize?' . http_build_query([
    'client_id'     => DISCORD_CLIENT_ID,
    'redirect_uri'  => DISCORD_REDIRECT_URI,
    'response_type' => 'code',
    'scope'         => $scope
]);
redirect($url);
