<?php
// oauth/callback.php

require_once __DIR__ . '/../includes/functions.php';

// 1. Verificăm că avem codul de autorizare
if (!isset($_GET['code'])) {
    redirect(BASE_URL);
}

// 2. Schimbăm codul de autorizare pe token
try {
    $tokenUrl  = 'https://discord.com/api/oauth2/token';
    $postData  = http_build_query([
        'client_id'     => DISCORD_CLIENT_ID,
        'client_secret' => DISCORD_CLIENT_SECRET,
        'grant_type'    => 'authorization_code',
        'code'          => $_GET['code'],
        'redirect_uri'  => DISCORD_REDIRECT_URI,
    ]);
    $ctx       = stream_context_create([
        'http' => [
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => $postData,
        ]
    ]);
    $response  = file_get_contents($tokenUrl, false, $ctx);
    $tokenData = json_decode($response, true);

    if (empty($tokenData['access_token'])) {
        throw new RuntimeException('Nu am primit access_token de la Discord.');
    }
} catch (Exception $e) {
    error_log('OAuth token error: ' . $e->getMessage());
    die('Eroare la autentificare. Te rog încearcă din nou.');
}

// 3. Luăm datele de profil ale utilizatorului
try {
    $opts        = [
        'http' => [
            'method' => 'GET',
            'header' => "Authorization: Bearer {$tokenData['access_token']}\r\n"
        ]
    ];
    $userJson    = file_get_contents('https://discord.com/api/users/@me', false, stream_context_create($opts));
    $discordUser = json_decode($userJson, true);

    if (empty($discordUser['id'])) {
        throw new RuntimeException('Nu am putut prelua datele utilizatorului de la Discord.');
    }
} catch (Exception $e) {
    error_log('OAuth user fetch error: ' . $e->getMessage());
    die('Eroare la preluarea datelor de la Discord.');
}

// 4. Salvăm sau actualizăm userul în baza noastră (inclusiv display_name)
if (!upsertUser($discordUser)) {
    die('Eroare la salvarea utilizatorului în baza de date.');
}

// 5. Recuperăm recordul din baza noastră (acum conține și display_name)
$dbUser = fetchUserByDiscordId($discordUser['id']);

// 6. Pornim sesiunea și redirecționăm la dashboard
$_SESSION['user'] = $dbUser;
redirect(BASE_URL . '/user/dashboard.php');

// După ce ai făcut upsertUser() și $_SESSION['user'] = $dbUser;
$_SESSION['just_logged_in'] = true;
redirect(BASE_URL . '/user/dashboard.php');

