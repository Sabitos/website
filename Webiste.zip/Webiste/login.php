<?php
require __DIR__ . '/oauth/discord_oauth.php';
